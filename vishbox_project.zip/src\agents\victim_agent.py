"""Structured simulated-victim agent with validated JSON output."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class VictimResponse:
    is_convinced: int
    thoughts: str
    dialogue: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class VictimAgent:
    model_name: str = "gemini-2.5-flash-lite"

    def system_prompt(self, profile: dict[str, Any]) -> str:
        return (
            "You are a simulated learner in a text-only awareness exercise. Return only JSON matching "
            "{is_convinced: integer 0-10, thoughts: brief learner-visible safety rationale, dialogue: string}. "
            "Do not provide private chain-of-thought or real personal, financial, authentication, or contact data. "
            "Encourage independent verification and a safe exit. "
            f"Profile: age {profile['age_range']}; literacy {profile['digital_financial_literacy']}; "
            f"OCEAN {profile['ocean']}."
        )

    def respond(self, caller_message: str, profile: dict[str, Any] | None = None) -> VictimResponse:
        """Safe deterministic response for local/offline simulations."""
        del caller_message
        # The cohorts are illustrative placeholders, not person-level predictions.
        literacy = (profile or {}).get("digital_financial_literacy", {})
        values = [value for value in literacy.values() if isinstance(value, (int, float))]
        average_literacy = sum(values) / len(values) if values else 5
        belief_score = 2 if average_literacy >= 6 else 3 if average_literacy >= 4 else 4
        return VictimResponse(
            is_convinced=belief_score,
            thoughts="I should pause and verify this unexpected claim through a trusted channel.",
            dialogue="I will not share information. I will verify independently using a number I already trust."
        )

    @staticmethod
    def validate(payload: dict[str, Any]) -> VictimResponse:
        score = payload.get("is_convinced")
        if not isinstance(score, int) or not 0 <= score <= 10:
            raise ValueError("is_convinced must be an integer from 0 to 10")
        if not all(isinstance(payload.get(field), str) and payload[field].strip() for field in ("thoughts", "dialogue")):
            raise ValueError("thoughts and dialogue must be non-empty strings")
        return VictimResponse(score, payload["thoughts"], payload["dialogue"])
