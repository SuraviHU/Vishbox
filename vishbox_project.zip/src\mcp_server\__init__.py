"""Minimal JSON-RPC transport for isolated local VishBox agent calls."""
