"""Risk analysis components for safe, text-only awareness simulations."""
