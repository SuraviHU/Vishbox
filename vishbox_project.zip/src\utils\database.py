"""Opt-in local SQLite storage for synthetic training sessions."""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4


DEFAULT_DB = Path(__file__).resolve().parents[2] / "data" / "processed" / "vishbox.sqlite3"


class SimulationStore:
    def __init__(self, path: Path = DEFAULT_DB):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self):
        with self._connect() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS simulations (
                id TEXT PRIMARY KEY, created_at TEXT NOT NULL, scenario TEXT NOT NULL,
                profile TEXT NOT NULL, report_json TEXT NOT NULL, training_only INTEGER NOT NULL DEFAULT 1
            )""")

    def save(self, result: dict[str, Any]) -> str:
        session_id = str(uuid4())
        with self._connect() as db:
            db.execute("INSERT INTO simulations VALUES (?, ?, ?, ?, ?, 1)", (
                session_id, datetime.now(timezone.utc).isoformat(), result["scenario"]["id"],
                result["profile"]["id"], json.dumps(result, ensure_ascii=False),
            ))
        return session_id

    def list_recent(self, limit: int = 20) -> list[dict[str, Any]]:
        with self._connect() as db:
            rows = db.execute(
                "SELECT id, created_at, scenario, profile FROM simulations ORDER BY created_at DESC LIMIT ?",
                (max(1, min(limit, 100)),),
            ).fetchall()
        return [dict(row) for row in rows]

    def get(self, session_id: str) -> dict[str, Any] | None:
        with self._connect() as db:
            row = db.execute("SELECT report_json FROM simulations WHERE id = ?", (session_id,)).fetchone()
        return json.loads(row["report_json"]) if row else None
