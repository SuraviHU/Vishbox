"""In-process client; replaceable with a standard MCP transport later."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
import sys

from src.mcp_server.mcp_server import VishBoxMCPServer, default_server


@dataclass
class VishBoxMCPClient:
    server: VishBoxMCPServer = field(default_factory=default_server)
    _next_id: int = 1

    def call(self, method: str, params: dict[str, Any] | None = None) -> Any:
        request = {"jsonrpc": "2.0", "id": self._next_id, "method": method, "params": params or {}}
        self._next_id += 1
        response = self.server.handle(request)
        if "error" in response:
            raise RuntimeError(response["error"]["message"])
        return response["result"]


async def call_standard_server(tool_name: str, arguments: dict[str, Any] | None = None) -> Any:
    """Call the optional SDK-backed MCP stdio server in a child process."""
    try:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client
    except ImportError as exc:
        raise RuntimeError("Install the MCP SDK with `pip install 'mcp>=1.0,<2'`") from exc
    if tool_name not in {"list_scenarios", "list_profiles", "simulate_safe_turn"}:
        raise ValueError("Unsupported VishBox MCP tool")
    params = StdioServerParameters(command=sys.executable,
                                   args=["-m", "src.mcp_server.standard_server"])
    async with stdio_client(params) as (read_stream, write_stream):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, arguments or {})
            if result.isError:
                raise RuntimeError("MCP server returned an error")
            return getattr(result, "structuredContent", None) or result.content
