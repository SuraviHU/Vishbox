"""Role-isolated agents for VishBox simulations."""
