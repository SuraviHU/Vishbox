"""Optional standards-based MCP server (MCP Python SDK v1 API)."""
from __future__ import annotations

from src.mcp_server.mcp_server import default_server

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as exc:  # Keep the offline application usable without MCP extras.
    raise RuntimeError("Install the MCP SDK with `pip install 'mcp>=1.0,<2'` to run this server") from exc

mcp = FastMCP("VishBox Training")
core = default_server()


@mcp.tool()
def list_scenarios() -> list[dict[str, str]]:
    """List fictional training scenarios."""
    return [{"id": item["id"], "name": item["name"]} for item in core.scenarios]


@mcp.tool()
def list_profiles() -> list[dict[str, str]]:
    """List synthetic, unvalidated profile cohorts."""
    return [{"id": item["id"], "age_range": item["age_range"]} for item in core.profiles]


@mcp.tool()
def simulate_safe_turn(scenario_id: str, profile_id: str, stage_id: str = "contact") -> dict:
    """Run one bounded awareness turn; no real identities, secrets, or actions are used."""
    response = core.handle({"method": "vishbox/simulate_turn", "params": {
        "scenario_id": scenario_id, "profile_id": profile_id, "stage_id": stage_id,
    }})
    if "error" in response:
        raise ValueError(response["error"]["message"])
    return response["result"]


if __name__ == "__main__":
    mcp.run()
