"""Coordinates safe simulation, analysis, and post-hoc coaching."""
from __future__ import annotations

from dataclasses import asdict
from typing import Any

from src.analytics.guidance_engine import generate_guidance
from src.analytics.risk_evaluator import RiskEvaluator
from src.analytics.roberta_classifier import RiskClassifier
from src.mcp_server.mcp_server import VishBoxMCPServer, default_server
from src.utils.report_generator import build_prevention_report


class ManagerAgent:
    def __init__(self, server: VishBoxMCPServer | None = None, classifier: RiskClassifier | None = None,
                 evaluator: RiskEvaluator | None = None):
        self.server = server or default_server()
        self.classifier = classifier or RiskClassifier()
        self.evaluator = evaluator or RiskEvaluator()

    def run(self, scenario_id: str, profile_id: str, rounds: int = 4) -> dict[str, Any]:
        if not 1 <= rounds <= self.evaluator.max_turns:
            raise ValueError(f"rounds must be between 1 and {self.evaluator.max_turns}")
        scenario = next((s for s in self.server.scenarios if s["id"] == scenario_id), None)
        profile = next((p for p in self.server.profiles if p["id"] == profile_id), None)
        if not scenario or not profile:
            raise ValueError("Unknown scenario or profile")

        turns = []
        observations = []
        next_index = 0
        for number in range(1, rounds + 1):
            stage = scenario["stages"][min(next_index, len(scenario["stages"]) - 1)]
            result = self.server.handle({"method": "vishbox/simulate_turn", "params": {
                "scenario_id": scenario_id, "profile_id": profile_id, "stage_id": stage["id"]
            }})
            if "error" in result:
                raise ValueError(result["error"]["message"])
            turn = result["result"]
            classification = self.classifier.classify(turn["caller_message"])
            response = turn["victim_response"]
            turns.append({
                "turn_number": number, "stage": stage["id"],
                "caller_message": turn["caller_message"],
                "victim_response": response,
                "classification": asdict(classification),
            })
            observations.append((number, response["is_convinced"],
                                 (classification.phishing_probability, classification.signals)))
            # Fixed stages keep each run reproducible and prevent tactical escalation.
            final_turn = (number >= rounds or number >= len(scenario["stages"]))
            critical_cue = (
                response["is_convinced"] / 10.0 * classification.phishing_probability
                >= self.evaluator.critical_threshold
                or any(signal in classification.signals for signal in
                       ("sensitive verification request", "financial action"))
            )
            if final_turn or critical_cue:
                break
            next_index += 1

        risk = self.evaluator.evaluate(observations)
        signals = [signal for item in turns for signal in item["classification"]["signals"]]
        return {
            "training_only": True,
            "watermark": "VISHBOX TRAINING SIMULATION — SYNTHETIC CONTENT",
            "scenario": {"id": scenario_id, "name": scenario["name"]},
            "profile": {"id": profile_id, "age_range": profile["age_range"]},
            "turns": turns,
            "risk": risk.to_dict(),
            "guidance": generate_guidance(signals),
            "classifier_status": {
                "model": turns[0]["classification"]["model"] if turns else "unavailable",
                "validated": all(t["classification"]["calibrated"] for t in turns),
            },
            "report": build_prevention_report(scenario["name"], profile["age_range"], turns, risk.to_dict(), generate_guidance(signals)),
        }
