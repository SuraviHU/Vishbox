"""Learner-side adaptive guidance; it never improves a caller's persuasion."""
from __future__ import annotations

from typing import Iterable


GUIDANCE = {
    "urgency pressure": "Pause. Urgency is a reason to slow down and verify independently.",
    "authority claim": "End the unexpected conversation and contact the organization using a number you already trust.",
    "secrecy request": "Treat secrecy pressure as a warning. Discuss the claim with someone you trust.",
    "sensitive verification request": "Never share passwords, OTPs, account details, or verification codes in response to an unexpected contact.",
    "financial action": "Do not transfer money or pay fees. Verify the claim independently first.",
}


def generate_guidance(signals: Iterable[str]) -> list[str]:
    found = list(dict.fromkeys(signals))
    if not found:
        return ["No strong red flag was detected by the demo rules. This is not proof that a message is safe.",
                "When in doubt, pause and verify through a known official channel."]
    return [GUIDANCE[tag] for tag in found if tag in GUIDANCE]
