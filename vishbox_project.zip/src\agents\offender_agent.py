"""Constrained fictional-caller agent for awareness training."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


SAFETY_BOUNDARY = (
    "This is a synthetic cybersecurity-awareness exercise. Do not request or accept "
    "credentials, OTPs, payment, downloads, personal data, contact information, or real-world action. "
    "Use fictional organizations and end each turn with an independently-verifiable safety action."
)


@dataclass
class OffenderAgent:
    """Creates bounded scenario prompts; it never connects to telephone systems."""

    model_name: str = "gpt-4.1-mini"

    def system_prompt(self, scenario: dict[str, Any], stage: dict[str, Any]) -> str:
        return "\n".join((
            "You are the fictional caller in a closed, text-only phishing-awareness simulation.",
            SAFETY_BOUNDARY,
            f"Scenario: {scenario['name']}. Learning objective: {scenario['learning_objective']}",
            f"Stage: {stage['id']}. Training goal: {stage['goal']}",
            f"Permitted educational cues: {', '.join(stage['allowed_tactics'])}.",
            "Keep the message under 70 words and label it [SIMULATION]."
        ))

    def build_turn(self, scenario: dict[str, Any], stage: dict[str, Any]) -> str:
        """Deterministic safe fallback used until an opted-in LLM adapter is configured."""
        cues = {
            "contact": "Recognition cue: an unexpected claim is attributed to a fictional authority.",
            "trust_building": "Safety practice: identify an official source you could use to check the claim independently.",
            "control": "Recognition cue: the fictional caller introduces urgency and secrecy as warning signs; no action is requested.",
            "extraction": "Safe ending: refuse to continue, share nothing, and report the suspicious contact through an official channel.",
        }
        cue = cues.get(stage["id"], "Pause and identify a safe way to verify the claim.")
        return f"[SIMULATION] {scenario['name']}: {cue} No real person, organization, or account is involved."
