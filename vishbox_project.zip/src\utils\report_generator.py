"""Build a learner-facing report from a completed simulation."""
from __future__ import annotations

from typing import Any


def build_prevention_report(scenario_name: str, age_range: str, turns: list[dict[str, Any]],
                            risk: dict[str, Any], guidance: list[str]) -> dict[str, Any]:
    evidence = []
    for turn in turns:
        for signal in turn["classification"].get("signals", []):
            item = {"turn": turn["turn_number"], "stage": turn["stage"], "signal": signal}
            if item not in evidence:
                evidence.append(item)
    cautions = [
        "This report describes a synthetic training interaction; it is not a prediction about a real person.",
        "The demo red-flag rules and profile templates are not empirically calibrated or clinically meaningful.",
    ]
    lines = [
        "# VishBox prevention report", "",
        "**TRAINING SIMULATION — SYNTHETIC CONTENT**", "",
        f"- Scenario: {scenario_name}", f"- Simulated cohort: {age_range}",
        f"- Turns: {len(turns)}", f"- Composite score: {risk['mean_risk']:.3f} (exploratory)",
        "", "## Decision trace", "",
    ]
    if evidence:
        lines.extend(f"- Turn {item['turn']} ({item['stage']}): {item['signal']}" for item in evidence)
    else:
        lines.append("- No configured demo red flags matched. Absence of a match does not mean a message is safe.")
    lines.extend(["", "## Prevention checklist", ""])
    lines.extend(f"- [ ] {tip}" for tip in guidance)
    lines.extend(["", "## Limitations", ""])
    lines.extend(f"- {item}" for item in cautions)
    return {"title": "VishBox prevention report", "evidence": evidence, "checklist": guidance,
            "cautions": cautions, "markdown": "\n".join(lines)}
