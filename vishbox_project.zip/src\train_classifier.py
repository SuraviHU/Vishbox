"""Fine-tune KLUE-RoBERTa only after label meaning and data-use rights are verified."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import random


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", type=Path)
    parser.add_argument("--positive-label", required=True, help="Verified source label to map to phishing (e.g. 1)")
    parser.add_argument("--negative-label", required=True, help="Verified source label to map to non-phishing (e.g. 0)")
    parser.add_argument("--approved-data-use", action="store_true", help="Confirm license and approved research purpose were reviewed")
    parser.add_argument("--output", type=Path, default=Path("models/klue-roberta-vishing"))
    parser.add_argument("--epochs", type=int, default=3)
    args = parser.parse_args()
    if not args.approved_data_use:
        parser.error("review the dataset license and permitted purpose, then pass --approved-data-use")
    if args.positive_label == args.negative_label:
        parser.error("positive and negative labels must differ")

    examples = []
    with args.csv_path.open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if not {"Transcript", "Label"}.issubset(reader.fieldnames or []):
            parser.error("CSV must contain Transcript and Label columns")
        for row in reader:
            label = (row.get("Label") or "").strip()
            text = (row.get("Transcript") or "").strip()
            if not text:
                continue
            if label == args.positive_label:
                examples.append((text, 1))
            elif label == args.negative_label:
                examples.append((text, 0))
            else:
                parser.error(f"unexpected label {label!r}; verify source mapping before training")
    if len(examples) < 20 or {label for _, label in examples} != {0, 1}:
        parser.error("need at least 20 usable rows and both mapped classes")
    counts = [sum(label == i for _, label in examples) for i in (0, 1)]
    if min(counts) < 5:
        parser.error("need at least five examples in each class for a holdout split")

    try:
        import numpy as np
        from datasets import Dataset
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import accuracy_score, precision_recall_fscore_support
        from transformers import (AutoModelForSequenceClassification, AutoTokenizer,
                                  DataCollatorWithPadding, Trainer, TrainingArguments)
    except ImportError as exc:
        parser.error(f"install requirements-ml.txt before training ({exc})")

    seed = 42
    random.seed(seed)
    np.random.seed(seed)
    train_rows, test_rows = train_test_split(examples, test_size=0.2, random_state=seed,
                                              stratify=[label for _, label in examples])
    tokenizer = AutoTokenizer.from_pretrained("klue/roberta-base")
    def make_dataset(rows):
        dataset = Dataset.from_dict({"text": [item[0] for item in rows], "labels": [item[1] for item in rows]})
        return dataset.map(lambda batch: tokenizer(batch["text"], truncation=True, max_length=512), batched=True)

    train_dataset, eval_dataset = make_dataset(train_rows), make_dataset(test_rows)
    model = AutoModelForSequenceClassification.from_pretrained(
        "klue/roberta-base", num_labels=2, id2label={0: "not_phishing", 1: "phishing"},
        label2id={"not_phishing": 0, "phishing": 1},
    )
    def metrics(prediction):
        labels = prediction.label_ids
        predicted = prediction.predictions.argmax(axis=-1)
        precision, recall, f1, _ = precision_recall_fscore_support(labels, predicted, average="binary", zero_division=0)
        return {"accuracy": accuracy_score(labels, predicted), "precision": precision, "recall": recall, "f1": f1}

    training = TrainingArguments(
        output_dir=str(args.output / "checkpoints"), num_train_epochs=args.epochs,
        learning_rate=2e-5, per_device_train_batch_size=8, per_device_eval_batch_size=16,
        eval_strategy="epoch", save_strategy="epoch", load_best_model_at_end=True,
        metric_for_best_model="f1", seed=seed, report_to="none",
    )
    trainer = Trainer(model=model, args=training, train_dataset=train_dataset,
                      eval_dataset=eval_dataset, tokenizer=tokenizer,
                      data_collator=DataCollatorWithPadding(tokenizer), compute_metrics=metrics)
    trainer.train()
    args.output.mkdir(parents=True, exist_ok=True)
    trainer.save_model(str(args.output))
    tokenizer.save_pretrained(str(args.output))
    print({"rows": len(examples), "class_counts": counts, "holdout_metrics": trainer.evaluate(),
           "seed": seed, "model": str(args.output),
           "warning": "Random row split may overstate performance when related transcripts overlap."})


if __name__ == "__main__":
    main()
