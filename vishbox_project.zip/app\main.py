"""Streamlit interface for the safe, local VishBox prototype."""
from __future__ import annotations

from pathlib import Path
import sys

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.agents.manager_agent import ManagerAgent
from src.mcp_server.mcp_server import default_server
from src.utils.database import SimulationStore


st.set_page_config(page_title="VishBox | Awareness Lab", page_icon="🛡️", layout="wide")
st.title("VishBox Awareness Lab")
st.caption("Text-only, synthetic phishing-awareness training. No calls, messages, credentials, or payments.")
st.warning("All dialogue is synthetic and watermarked. Profile cohorts are illustrative, not predictions about real people.")

server = default_server()
scenario_by_id = {s["id"]: s for s in server.scenarios}
profile_by_id = {p["id"]: p for p in server.profiles}

with st.sidebar:
    st.header("Simulation setup")
    scenario_id = st.selectbox("Scenario", list(scenario_by_id), format_func=lambda key: scenario_by_id[key]["name"])
    profile_id = st.selectbox("Synthetic cohort", list(profile_by_id), format_func=lambda key: profile_by_id[key]["age_range"])
    rounds = st.slider("Maximum dialogue turns", 1, 4, 4)
    run = st.button("Start simulation", type="primary", use_container_width=True)
    st.divider()
    st.caption("Risk scores use an unvalidated demo heuristic until a permitted, correctly labeled model is configured.")

if run:
    try:
        st.session_state["result"] = ManagerAgent().run(scenario_id, profile_id, rounds)
    except (ValueError, OSError) as exc:
        st.error(f"Could not complete simulation: {exc}")

result = st.session_state.get("result")
if result:
    st.subheader(result["watermark"])
    left, mid, right = st.columns(3)
    left.metric("Turns", len(result["turns"]))
    mid.metric("Exploratory composite score", f"{result['risk']['mean_risk']:.3f}")
    right.metric("Classifier", "Validated" if result["classifier_status"]["validated"] else "Demo only")

    st.subheader("Dialogue and decision trace")
    points = []
    for turn in result["turns"]:
        with st.container(border=True):
            st.markdown(f"**Turn {turn['turn_number']} · {turn['stage'].replace('_', ' ').title()}**")
            st.markdown(f"**[SIMULATION] Caller cue:** {turn['caller_message']}")
            victim = turn["victim_response"]
            st.markdown(f"**Simulated learner:** {victim['dialogue']}")
            st.caption(f"Rationale: {victim['thoughts']}")
            item = next((t for t in result["risk"]["turns"] if t["turn_number"] == turn["turn_number"]), None)
            if item:
                points.append({"Turn": item["turn_number"], "Risk": item["turn_risk"]})
                st.caption(f"Demo signal: {', '.join(item['signals']) or 'none matched'} · score {item['turn_risk']:.3f}")
    if points:
        st.subheader("Turn-level exploratory score")
        st.line_chart(points, x="Turn", y="Risk")

    st.subheader("Prevention guidance")
    for instruction in result["guidance"]:
        st.markdown(f"- {instruction}")
    st.markdown(result["report"]["markdown"])
    st.download_button("Download report (Markdown)", result["report"]["markdown"],
                       file_name="vishbox_prevention_report.md", mime="text/markdown")
    if st.button("Save synthetic session locally"):
        session_id = SimulationStore().save(result)
        st.success(f"Saved locally. Session ID: {session_id}")

with st.expander("Dataset profile (aggregate metadata only)"):
    try:
        from src.data_tools import build_report
        st.json(build_report())
    except (OSError, UnicodeError, ValueError) as exc:
        st.info(f"Dataset profile not available: {exc}")

with st.expander("Research scope and future work"):
    st.markdown("""
    - **Current prototype:** deterministic, text-only simulated turns, synthetic cohorts, red-flag rules, a transparent composite score, prevention guidance, and opt-in local reports.
    - **Model research:** validate the dataset label map and license; then train/evaluate a KLUE-RoBERTa model on approved voice-phishing transcripts.
    - **Future scope:** privacy-reviewed voice/sentiment experiments, cross-language calibration, additional institutional scam patterns, and controlled human evaluation with informed consent and ethics approval.
    """)
