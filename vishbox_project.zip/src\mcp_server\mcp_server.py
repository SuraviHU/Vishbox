"""Local-only MCP-style server boundary for role-isolated simulation agents."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from src.agents.offender_agent import OffenderAgent
from src.agents.victim_agent import VictimAgent


@dataclass
class VishBoxMCPServer:
    """No network, filesystem, telephony, payment, or credential tools are exposed."""

    config_dir: Path

    def __post_init__(self) -> None:
        self.offender = OffenderAgent()
        self.victim = VictimAgent()
        self.scenarios = self._load("scenarios.json")["scenarios"]
        self.profiles = self._load("victim_profiles.json")["profiles"]

    def _load(self, filename: str) -> dict[str, Any]:
        return json.loads((self.config_dir / filename).read_text(encoding="utf-8"))

    def handle(self, request: dict[str, Any]) -> dict[str, Any]:
        request_id = request.get("id")
        try:
            method = request["method"]
            params = request.get("params", {})
            if method == "vishbox/list_scenarios":
                result = [{"id": s["id"], "name": s["name"]} for s in self.scenarios]
            elif method == "vishbox/list_profiles":
                result = [{"id": p["id"], "age_range": p["age_range"]} for p in self.profiles]
            elif method == "vishbox/simulate_turn":
                result = self._simulate_turn(params)
            else:
                raise ValueError(f"Unsupported method: {method}")
            return {"jsonrpc": "2.0", "id": request_id, "result": result}
        except (KeyError, ValueError) as exc:
            return {"jsonrpc": "2.0", "id": request_id, "error": {"code": -32602, "message": str(exc)}}

    def _simulate_turn(self, params: dict[str, Any]) -> dict[str, Any]:
        scenario = next((s for s in self.scenarios if s["id"] == params.get("scenario_id")), None)
        profile = next((p for p in self.profiles if p["id"] == params.get("profile_id")), None)
        stage_id = params.get("stage_id", "contact")
        if scenario is None or profile is None:
            raise ValueError("Unknown scenario_id or profile_id")
        stage = next((item for item in scenario["stages"] if item["id"] == stage_id), None)
        if stage is None:
            raise ValueError("Unknown stage_id")
        caller = self.offender.build_turn(scenario, stage)
        victim = self.victim.respond(caller, profile)
        return {"caller_message": caller, "victim_response": victim.to_dict(), "training_only": True}


def default_server() -> VishBoxMCPServer:
    return VishBoxMCPServer(Path(__file__).resolve().parents[2] / "config")
