"""Privacy-conscious dataset inspection helpers for the local VishBox project.

Only aggregate metadata is emitted. Conversation contents and account-level rows
are never included in reports.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path
from typing import Any, TextIO


DEFAULT_DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "raw"
CONVERSATION_FILE = "KoBERT_dataset_v3.0.csv"
ACCOUNT_FILE = "우체국금융개발원_우체국 금융 사기계좌 정보_20260630.csv"
ENCODINGS = ("utf-8-sig", "cp949", "euc-kr")


def _open_csv(path: Path) -> tuple[TextIO, str]:
    """Open a CSV using the first supported encoding without losing Korean text."""
    last_error: UnicodeError | None = None
    for encoding in ENCODINGS:
        try:
            stream = path.open("r", encoding=encoding, newline="")
            stream.read(4096)
            stream.seek(0)
            return stream, encoding
        except UnicodeError as exc:
            last_error = exc
            try:
                stream.close()
            except UnboundLocalError:
                pass
    raise UnicodeError(f"Could not decode {path.name} with supported Korean encodings") from last_error


def profile_conversations(path: Path) -> dict[str, Any]:
    """Summarize transcript row counts, label distribution, and data quality."""
    stream, encoding = _open_csv(path)
    with stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames or []
        if not {"Transcript", "Label"}.issubset(fields):
            raise ValueError("Expected KoBERT columns: Transcript and Label")
        labels: Counter[str] = Counter()
        rows = empty_transcripts = invalid_labels = 0
        total_chars = 0
        for row in reader:
            rows += 1
            transcript = (row.get("Transcript") or "").strip()
            label = (row.get("Label") or "").strip()
            empty_transcripts += not bool(transcript)
            total_chars += len(transcript)
            labels[label] += 1
            invalid_labels += label not in {"0", "1"}
    return {
        "dataset": path.name,
        "encoding": encoding,
        "rows": rows,
        "labels": dict(sorted(labels.items())),
        "mean_transcript_characters": round(total_chars / rows, 1) if rows else 0,
        "empty_transcripts": empty_transcripts,
        "invalid_binary_labels": invalid_labels,
        "label_semantics": "Not specified; values are reported without interpretation.",
    }


def profile_accounts(path: Path) -> dict[str, Any]:
    """Summarize account dataset structure without reporting row-level values."""
    stream, encoding = _open_csv(path)
    with stream:
        reader = csv.reader(stream)
        header = next(reader, [])
        widths: Counter[int] = Counter()
        rows = 0
        for fields in reader:
            if not fields or not any(value.strip() for value in fields):
                continue
            rows += 1
            widths[len(fields)] += 1
    return {
        "dataset": path.name,
        "encoding": encoding,
        "rows": rows,
        "column_count": len(header),
        "headers": [name.strip() for name in header],
        "row_width_distribution": {str(k): v for k, v in sorted(widths.items())},
        "consistent_row_width": len(widths) <= 1 and (not widths or next(iter(widths)) == len(header)),
        "privacy": "Row-level victim/account details are intentionally excluded.",
    }


def build_report(data_dir: Path = DEFAULT_DATA_DIR) -> dict[str, Any]:
    return {
        "project": "VishBox",
        "report_type": "local_dataset_profile",
        "datasets": [
            profile_conversations(data_dir / CONVERSATION_FILE),
            profile_accounts(data_dir / ACCOUNT_FILE),
        ],
        "caution": (
            "Confirm dataset documentation, label meaning, licensing, and permitted use "
            "before training or drawing behavioral conclusions."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Print a privacy-conscious profile of VishBox raw datasets.")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    args = parser.parse_args()
    print(json.dumps(build_report(args.data_dir), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
