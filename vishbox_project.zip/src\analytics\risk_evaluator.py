"""Composite, turn-level risk calculation used by the research prototype."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Sequence


@dataclass(frozen=True)
class RiskTurn:
    turn_number: int
    persuasion_intensity: float
    detection_probability: float
    turn_risk: float
    critical: bool
    signals: tuple[str, ...] = ()


@dataclass(frozen=True)
class RiskSummary:
    mean_risk: float
    peak_risk: float
    critical: bool
    termination_reason: str | None
    turns: tuple[RiskTurn, ...]

    def to_dict(self):
        return {
            "mean_risk": self.mean_risk,
            "peak_risk": self.peak_risk,
            "critical": self.critical,
            "termination_reason": self.termination_reason,
            "turns": [asdict(turn) for turn in self.turns],
        }


class RiskEvaluator:
    """Implements R-bar = mean((is_convinced / 10) * phishing probability)."""

    def __init__(self, critical_threshold: float = 0.70, max_turns: int = 8):
        if not 0 < critical_threshold <= 1:
            raise ValueError("critical_threshold must be in (0, 1]")
        if max_turns < 1:
            raise ValueError("max_turns must be positive")
        self.critical_threshold = critical_threshold
        self.max_turns = max_turns

    def evaluate(self, observations: Sequence[tuple[int, float, tuple[float, Sequence[str]]]]) -> RiskSummary:
        turns: list[RiskTurn] = []
        reason = None
        for number, convinced, classifier_result in observations[: self.max_turns]:
            probability, signals = classifier_result
            if not 0 <= convinced <= 10 or not 0 <= probability <= 1:
                raise ValueError("convinced must be 0-10 and probability must be 0-1")
            intensity = convinced / 10.0
            score = intensity * probability
            # Sensitive action cues always stop the interaction, irrespective of score.
            critical_signal = any(s in signals for s in ("sensitive verification request", "financial action"))
            critical = score >= self.critical_threshold or critical_signal
            turns.append(RiskTurn(number, intensity, probability, score, critical, tuple(signals)))
            if critical:
                reason = "critical cue detected; simulation ended for safety"
                break
        if reason is None and len(turns) >= self.max_turns:
            reason = "maximum turn limit reached"
        risks = [turn.turn_risk for turn in turns]
        mean_risk = sum(risks) / len(risks) if risks else 0.0
        return RiskSummary(mean_risk, max(risks, default=0.0), any(t.critical for t in turns), reason, tuple(turns))
