"""Optional local KLUE-RoBERTa classifier with an explicitly unvalidated fallback."""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import re
from typing import Any


@dataclass(frozen=True)
class Classification:
    phishing_probability: float
    model: str
    calibrated: bool
    signals: tuple[str, ...] = ()


class RiskClassifier:
    """Load a fine-tuned local model when available; otherwise use a demo heuristic.

    The heuristic is for UI demonstration only and is not a detector. Model scores
    are only marked calibrated when the caller explicitly configures that claim.
    """

    def __init__(self, model_path: str | Path | None = None, calibrated: bool = False):
        configured_path = model_path or os.environ.get("VISHBOX_MODEL_PATH")
        self.model_path = Path(configured_path) if configured_path else None
        self.calibrated = calibrated
        self._pipeline: Any = None
        self._load_error: str | None = None
        if self.model_path and self.model_path.exists():
            try:
                from transformers import pipeline
                self._pipeline = pipeline(
                    "text-classification", model=str(self.model_path), tokenizer=str(self.model_path),
                    top_k=None,
                )
            except (ImportError, OSError, ValueError) as exc:
                self._load_error = str(exc)

    @property
    def ready(self) -> bool:
        return self._pipeline is not None

    def classify(self, text: str) -> Classification:
        if self._pipeline is not None:
            scores = self._pipeline(text[:4000])[0]
            by_label = {str(item["label"]).lower(): float(item["score"]) for item in scores}
            positive = next((score for label, score in by_label.items() if label in {"1", "phishing", "fraud", "label_1"}), None)
            if positive is None:
                raise ValueError("Model labels must identify the positive class as 1 or phishing")
            return Classification(min(1.0, max(0.0, positive)), self.model_path.name, self.calibrated)

        rules = {
            "urgency": (r"urgent|urgency|immediately|right now|긴급|즉시|지금 바로", "urgency pressure"),
            "authority": (r"authority|police|prosecutor|bank|government|fictional authority|경찰|검찰|은행|기관", "authority claim"),
            "secrecy": (r"keep this secret|do not tell|don't tell|비밀|알리지 마", "secrecy request"),
            "verification": (r"verification code|one.?time code|otp|password|account number|인증번호|비밀번호|계좌번호", "sensitive verification request"),
            "money": (r"transfer money|make a payment|payment|fee|송금|이체|결제|수수료", "financial action"),
        }
        found = [description for pattern, description in rules.values() if re.search(pattern, text, re.IGNORECASE)]
        probability = min(0.95, 0.08 + 0.17 * len(found)) if found else 0.05
        return Classification(probability, "demo-red-flag-heuristic", False, tuple(found))
