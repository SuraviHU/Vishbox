"""Local persistence and reporting utilities."""
