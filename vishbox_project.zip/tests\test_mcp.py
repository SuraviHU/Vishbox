from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.mcp_server.mcp_client import VishBoxMCPClient


def test_mcp_turn_is_safe_and_structured():
    turn = VishBoxMCPClient().call("vishbox/simulate_turn", {
        "scenario_id": "loan_pretext", "profile_id": "cohort_60s", "stage_id": "contact"
    })
    assert turn["training_only"] is True
    assert 0 <= turn["victim_response"]["is_convinced"] <= 10
    assert "SIMULATION" in turn["caller_message"]
