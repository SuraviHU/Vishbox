"""VishBox training simulation package."""
