"""VishBox training UI."""
